﻿Imports System.Data.Odbc
Imports System.Data
Imports System.Data.SqlClient
Partial Class Signup
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim constr = "Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\WebSite8\WebSite8\App_Data\Database.mdf;Integrated Security=True"
        Dim con As New SqlConnection(constr)

        Dim Q = "SELECT * FROM demologin WHERE user_id = '" & userid.Text & "'"
        Dim da As New SqlDataAdapter(Q, con)
        Dim ds As New DataSet
        da.Fill(ds)
        If ds.Tables(0).Rows.Count = 0 Then
            con.Open()
            Q = "Insert into dbo.demologin (user_id, pasword) values ('" & userid.Text & "' , '" & password.Text & "')"
            Dim cmd As New SqlCommand(Q, con)
            cmd.ExecuteNonQuery()
            Label3.Text = "USER" & userid.Text & "  CREATED with passowrd : " & password.Text
        Else
            Label3.Text = "ACCOUNT ALREADY EXIST TRY USING DIFFERENT  *USER ID*  "
        End If
    End Sub
End Class
