﻿Imports System.Data.Odbc
Imports System.Data
Imports System.Data.SqlClient
Partial Class Signup
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim constr = "Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\WebSite8\WebSite8\WebSite8\App_Data\Database.mdf;Integrated Security=True"
        Dim con As New SqlConnection(constr)
        con.Open()
        Dim Q = "Insert into dbo.demologin (user_id, pasword) values ('" & userid.Text & "' , '" & password.Text & "')"
        Dim cmd As New SqlCommand(Q, con)
        cmd.ExecuteNonQuery()
        Response.Redirect("login.aspx")
    End Sub
End Class
