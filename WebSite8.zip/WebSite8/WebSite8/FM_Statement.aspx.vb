﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class FM_Statement
    Inherits System.Web.UI.Page

    Private Sub FM_Statement_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim constr = "Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\WebSite8\WebSite8\App_Data\Database.mdf;Integrated Security=True"
        Dim con As New SqlConnection(constr)
        Dim currM As String = Request.QueryString("mth")
        Dim CurMonth As Date = currM
        Dim cur_month As Integer = CurMonth.Month
        Response.Write(cur_month)
        '***********************CREDIT TABLE*******************************
        Dim Q = "Select Date, Mode, Amount, Description From statement WHERE datepart(month, Date) = " & cur_month & " AND Type = 'Credit' "
        Dim da As New SqlDataAdapter(Q, con)
        Dim ds As New DataSet
        da.Fill(ds)
        GridView1.DataSource = ds
        GridView1.DataBind()
        '***********************DEBIT TABLE*********************************
        Q = "Select Date, Mode, Amount, Description From statement WHERE datepart(month, Date) = " & cur_month & " AND Type = 'Debit' "
        da = New SqlDataAdapter(Q, con)
        ds = New DataSet
        da.Fill(ds)
        GridView2.DataSource = ds
        GridView2.DataBind()
        '*******************************************************************
        '***********Cash Credit

        Q = "SELECT SUM(Amount) FROM statement WHERE Mode = 'Cash' AND Type = 'Credit' AND datepart(month, Date) = " & cur_month
        da = New SqlDataAdapter(Q, con)
        ds = New DataSet
        da.Fill(ds)
        Dim CCredit As Integer = 0
        If Not IsDBNull(ds.Tables(0).Rows(0).Item(0)) Then
            CCredit = ds.Tables(0).Rows(0).Item(0)
        End If
        ''***********Cash Debit
        Q = "SELECT SUM(Amount) FROM statement WHERE Mode = 'Cash' AND Type = 'Debit' AND datepart(month, Date) = " & cur_month
        da = New SqlDataAdapter(Q, con)
        ds = New DataSet
        da.Fill(ds)
        Dim CDebit As Integer = 0
        If Not IsDBNull(ds.Tables(0).Rows(0).Item(0)) Then
            CDebit = ds.Tables(0).Rows(0).Item(0)
        End If

        ''***********Bank Credit

        Q = "SELECT SUM(Amount) FROM statement WHERE Mode = 'Bank' AND Type = 'Credit' AND datepart(month, Date) = " & cur_month
        da = New SqlDataAdapter(Q, con)
        ds = New DataSet
        da.Fill(ds)
        Dim BCredit As Integer = 0
        If Not IsDBNull(ds.Tables(0).Rows(0).Item(0)) Then
            BCredit = ds.Tables(0).Rows(0).Item(0)
        End If

        ''******Bank Debit

        Q = "SELECT SUM(Amount) FROM statement WHERE Mode = 'Bank' AND Type = 'Debit' AND datepart(month, Date) = " & cur_month
        da = New SqlDataAdapter(Q, con)
        ds = New DataSet
        da.Fill(ds)
        Dim BDebit As Integer = 0
        If Not IsDBNull(ds.Tables(0).Rows(0).Item(0)) Then
            BDebit = ds.Tables(0).Rows(0).Item(0)
        End If

        '###################   CREDIT DEBIT FOR PREVIOUS MONTH ###############################

        Q = "SELECT SUM(Amount) FROM statement WHERE Mode = 'Cash' AND Type = 'Credit' AND datepart(month, Date) < " & cur_month
        da = New SqlDataAdapter(Q, con)
        ds = New DataSet
        da.Fill(ds)
        Dim XCCredit As Integer = 0
        If Not IsDBNull(ds.Tables(0).Rows(0).Item(0)) Then
            XCCredit = ds.Tables(0).Rows(0).Item(0)
        End If
        ''***********Cash Debit
        Q = "SELECT SUM(Amount) FROM statement WHERE Mode = 'Cash' AND Type = 'Debit' AND datepart(month, Date) < " & cur_month
        da = New SqlDataAdapter(Q, con)
        ds = New DataSet
        da.Fill(ds)
        Dim XCDebit As Integer = 0
        If Not IsDBNull(ds.Tables(0).Rows(0).Item(0)) Then
            XCDebit = ds.Tables(0).Rows(0).Item(0)
        End If

        ''***********Bank Credit

        Q = "SELECT SUM(Amount) FROM statement WHERE Mode = 'Bank' AND Type = 'Credit' AND datepart(month, Date) < " & cur_month
        da = New SqlDataAdapter(Q, con)
        ds = New DataSet
        da.Fill(ds)
        Dim XBCredit As Integer = 0
        If Not IsDBNull(ds.Tables(0).Rows(0).Item(0)) Then
            XBCredit = ds.Tables(0).Rows(0).Item(0)
        End If

        ''******Bank Debit

        Q = "SELECT SUM(Amount) FROM statement WHERE Mode = 'Bank' AND Type = 'Debit' AND datepart(month, Date) < " & cur_month
        da = New SqlDataAdapter(Q, con)
        ds = New DataSet
        da.Fill(ds)
        Dim XBDebit As Integer = 0
        If Not IsDBNull(ds.Tables(0).Rows(0).Item(0)) Then
            XBDebit = ds.Tables(0).Rows(0).Item(0)
        End If

        Cash.Text = "CASH ON HAND   : " & ((XCCredit - XCDebit) + (CCredit - CDebit))
        Bank.Text = "MONEY ON BANK  : " & ((XBCredit - XBDebit) + (BCredit - BDebit))
        TotalMoney.Text = "TOTAL MONEY    : " & ((XCCredit + XBCredit - XCDebit - XBDebit) + (CCredit + BCredit - CDebit - BDebit))
        Q = "SELECT Opening_Amount FROM Monthly_Statement WHERE datepart(month, Month) = " & cur_month
        da = New SqlDataAdapter(Q, con)
        ds = New DataSet
        da.Fill(ds)

        Dim Opening As Integer = 0
        If Not IsDBNull(ds.Tables(0).Rows(0).Item(0)) Then
            Opening = ds.Tables(0).Rows(0).Item(0)
            Label1.Text = "OPENING BALANCE : " & Opening
        Else
            Label1.Text = "MONTH NOT CLOSED"
            Label2.Visible = False
        End If

        Q = "SELECT Closing_Amount FROM Monthly_Statement WHERE datepart(month, Month) = " & cur_month
        da = New SqlDataAdapter(Q, con)
        ds = New DataSet
        da.Fill(ds)

        Dim Closing As Integer = 0
        If Not IsDBNull(ds.Tables(0).Rows(0).Item(0)) Then
            Closing = ds.Tables(0).Rows(0).Item(0)
            Label2.Text = "CLOSING BALANCE :" & Closing
        End If

    End Sub
End Class
