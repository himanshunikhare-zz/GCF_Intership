﻿
Partial Class MasterPage
    Inherits System.Web.UI.MasterPage
    Protected Sub signup_btn_Click(sender As Object, e As EventArgs) Handles signup_btn.Click
        Response.Redirect("Signup.aspx")
    End Sub

    Private Sub user_btn_Click(sender As Object, e As EventArgs) Handles user_btn.Click
        If Session("loggedin") = 1 Then
            Session("loggedin") = 0
            Response.Redirect("login.aspx")

        Else
            Response.Redirect("users.aspx")
        End If


    End Sub

    Private Sub MasterPage_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Session("loggedin") = 1 Then
            signup_btn.Visible = False
            user_btn.Text = "LOGOUT"
        Else
            signup_btn.Visible = True
            user_btn.Text = "USERS"
        End If
    End Sub
End Class

