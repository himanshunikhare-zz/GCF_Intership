﻿
Partial Class MasterPage
    Inherits System.Web.UI.MasterPage
    Protected Sub signup_btn_Click(sender As Object, e As EventArgs) Handles signup_btn.Click
        If Session("loggedin") = 1 Then

            Response.Redirect("statement.aspx")

        Else
            Response.Redirect("Signup.aspx")
        End If
    End Sub

    Private Sub user_btn_Click(sender As Object, e As EventArgs) Handles user_btn.Click
        If Session("loggedin") = 1 Then
            Session("loggedin") = 0
        End If
        Response.Redirect("login.aspx")


    End Sub

    Private Sub MasterPage_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Session("loggedin") = 1 Then
            signup_btn.Text = "HOME"
            user_btn.Text = "LOGOUT"
            Button1.Visible = True
        Else
            signup_btn.Visible = True
            user_btn.Text = "LOGIN"
            Button1.Visible = False
        End If
    End Sub
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Response.Redirect("Final_Statement.aspx")
    End Sub
End Class

