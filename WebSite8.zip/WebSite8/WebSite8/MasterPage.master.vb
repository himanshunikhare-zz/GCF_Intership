﻿
Partial Class MasterPage
    Inherits System.Web.UI.MasterPage
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Response.Redirect("login.aspx")
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Response.Redirect("Default.aspx")


    End Sub

    Private Sub MasterPage_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Session("loggedin") = 1 Or Session("loggedin") = 2 Then
            Button2.Text = "HOME"
            Button1.Text = "LOGOUT"
        Else
            Button1.Text = "LOGIN"

            Button2.Visible = False
        End If
    End Sub
End Class

