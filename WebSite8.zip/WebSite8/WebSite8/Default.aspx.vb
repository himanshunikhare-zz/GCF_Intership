﻿
Partial Class _Default
    Inherits System.Web.UI.Page

    Protected Sub trans_Click(sender As Object, e As EventArgs) Handles trans.Click
        Response.Redirect("statement.aspx")
    End Sub
    Protected Sub mclosing_Click(sender As Object, e As EventArgs) Handles mclosing.Click
        Response.Redirect("closing.aspx")
    End Sub
    Protected Sub mstatement_Click(sender As Object, e As EventArgs) Handles mstatement.Click
        Response.Redirect("closing.aspx")
    End Sub
    Protected Sub fstatement_Click(sender As Object, e As EventArgs) Handles fstatement.Click
        Response.Redirect("Final_Statement.aspx")
    End Sub
    Protected Sub signout_Click(sender As Object, e As EventArgs) Handles signout.Click
        Response.Redirect("Login.aspx")
    End Sub

    Private Sub _Default_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not (Session("loggedin") = 1 Or Session("loggedin") = 2) Then
            Response.Redirect("login.aspx")
        End If
        If Session("loggedin") = 2 Then
            users.Visible = True
            signup.Visible = True
        End If
    End Sub
    Protected Sub signout0_Click(sender As Object, e As EventArgs) Handles signup.Click
        Response.Redirect("Signup.aspx")
    End Sub
    Protected Sub users_Click(sender As Object, e As EventArgs) Handles users.Click
        Response.Redirect("users.aspx")
    End Sub
End Class
