﻿'Imports System.Data.Odbc
Imports System.Data
Imports System.Data.SqlClient
Partial Class users
    Inherits System.Web.UI.Page

    Private Sub users_Load(sender As Object, e As EventArgs) Handles Me.Load


        Dim constr = "Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\WebSite8\WebSite8\App_Data\Database.mdf;Integrated Security=True"
        Dim con As New SqlConnection(constr)
        con.Open()
        Dim Q = "SELECT * FROM demologin "
        Dim da As New SqlDataAdapter(Q, con)
        Dim ds As New DataSet
        da.Fill(ds)
        GridView1.DataSource = ds
        GridView1.DataBind()
    End Sub
End Class
