﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class Final_Statement
    Inherits System.Web.UI.Page

    Private Sub Final_Statement_Load(sender As Object, e As EventArgs) Handles Me.Load
        '********************     CHECKING SESSION     ********************
        If Not (Session("loggedin") = 1 Or Session("loggedin") = 2) Then
            Response.Redirect("login.aspx")
        End If
        '******************************************************************
        'Dim dt As New DataTable
        'dt.Columns.Add("ONE")
        'dt.Columns.Add("TWO")
        'For i = 0 To 5
        '    Dim dr As DataRow = dt.NewRow
        '    dr.Item(0) = 5
        '    dr.Item(1) = 5
        '    dt.Rows.Add(dr)
        'Next
        Dim constr = "Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\WebSite8\WebSite8\App_Data\Database.mdf;Integrated Security=True"
        Dim con As New SqlConnection(constr)
        Dim Q = "SELECT * FROM  statement"
        Dim da As New SqlDataAdapter(Q, con)
        Dim ds As New DataSet
        da.Fill(ds)
        GridView1.DataSource = ds
        GridView1.DataBind()

        '######################################### CASH AND BANK STATEMENT

        '***********Cash Credit

        Q = "SELECT SUM(Amount) FROM statement WHERE Mode = 'Cash' AND Type = 'Credit' "
        da = New SqlDataAdapter(Q, con)
        ds = New DataSet
        da.Fill(ds)
        Dim CCredit As Integer = 0
        If Not IsDBNull(ds.Tables(0).Rows(0).Item(0)) Then
            CCredit = ds.Tables(0).Rows(0).Item(0)
        End If
        '***********Cash Debit
        Q = "SELECT SUM(Amount) FROM statement WHERE Mode = 'Cash' AND Type = 'Debit' "
        da = New SqlDataAdapter(Q, con)
        ds = New DataSet
        da.Fill(ds)
        Dim CDebit As Integer = 0
        If Not IsDBNull(ds.Tables(0).Rows(0).Item(0)) Then
            CDebit = ds.Tables(0).Rows(0).Item(0)
        End If

        '***********Bank Credit

        Q = "SELECT SUM(Amount) FROM statement WHERE Mode = 'Bank' AND Type = 'Credit' "
        da = New SqlDataAdapter(Q, con)
        ds = New DataSet
        da.Fill(ds)
        Dim BCredit As Integer = 0
        If Not IsDBNull(ds.Tables(0).Rows(0).Item(0)) Then
            BCredit = ds.Tables(0).Rows(0).Item(0)
        End If

        '******Bank Debit

        Q = "SELECT SUM(Amount) FROM statement WHERE Mode = 'Bank' AND Type = 'Debit' "
        da = New SqlDataAdapter(Q, con)
        ds = New DataSet
        da.Fill(ds)
        Dim BDebit As Integer = 0
        If Not IsDBNull(ds.Tables(0).Rows(0).Item(0)) Then
            BDebit = ds.Tables(0).Rows(0).Item(0)
        End If

        Cash.Text = "CASH ON HAND   : " & (CCredit - CDebit)
        Bank.Text = "MONEY ON BANK  : " & (BCredit - BDebit)
        TotalMoney.Text = "TOTAL MONEY    : " & (CCredit + BCredit - CDebit - BDebit)
    End Sub
End Class
