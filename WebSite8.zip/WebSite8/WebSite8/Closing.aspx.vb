﻿Imports System.Data.SqlClient
Imports System.Data
Partial Class Closing
    Inherits System.Web.UI.Page


    Protected Sub CloseMonth_Click(sender As Object, e As EventArgs) Handles CloseMonth.Click
        Dim constr = "Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\WebSite8\WebSite8\App_Data\Database.mdf;Integrated Security=True"
        Dim con As New SqlConnection(constr)
        'con.Open()

        Dim Q = "SELECT Amount, Type FROM statement WHERE datepart(month,date)=" & Month.SelectedItem.Value & " "
        Dim da As New SqlDataAdapter(Q, con)
        Dim ds As New DataSet
        da.Fill(ds)
        GridView1.DataSource = ds
        GridView1.DataBind()
        Label3.Text = "Monthly Statement For Selected Month"
        Dim Credited As Integer
        Dim Debited As Integer
        Q = "SELECT SUM(Amount) FROM statement WHERE datepart(month,date)=" & Month.SelectedItem.Value & " AND Type = 'Credit'"
        da = New SqlDataAdapter(Q, con)
        ds = New DataSet
        da.Fill(ds)
        If Not IsDBNull(ds.Tables(0).Rows(0).Item(0)) Then
            Credited = ds.Tables(0).Rows(0).Item(0)
        Else
            Credited = 0

        End If

        Q = "SELECT SUM(Amount) FROM statement WHERE datepart(month,date)=" & Month.SelectedItem.Value & " AND Type = 'Debit'"
        da = New SqlDataAdapter(Q, con)
        ds = New DataSet
        da.Fill(ds)
        If Not IsDBNull(ds.Tables(0).Rows(0).Item(0)) Then
            Debited = ds.Tables(0).Rows(0).Item(0)
        Else
            Debited = 0
        End If

        '###########################################
        Dim Opening_amount As Integer = 0
        'Dim XCredited As Integer
        'Dim XDebited As Integer

        Q = "SELECT Closing_Amount FROM Monthly_Statement WHERE datepart(month,Month)=" & Month.SelectedItem.Value & "-1 "
        da = New SqlDataAdapter(Q, con)
        ds = New DataSet
        da.Fill(ds)

        If (ds.Tables(0).Rows.Count() <> 0) Or Month.SelectedItem.Value = 1 Then
            If (ds.Tables(0).Rows.Count() <> 0) Then
                Opening_amount = ds.Tables(0).Rows(0).Item(0)
            End If
            Dim Closing_amount As Integer = Opening_amount + Credited - Debited
            Label1.Text = "Closing Balance"
            Label2.Text = Closing_amount
            Label4.Text = "Opening Balance"
            Label5.Text = Opening_amount
            Dim cur_month As String = "2018-" & Month.SelectedItem.Value & "-01"
            Q = "Select Month From Monthly_Statement WHERE Month = '" & cur_month & "'"
            da = New SqlDataAdapter(Q, con)
            ds = New DataSet
            da.Fill(ds)
            If ds.Tables(0).Rows.Count = 0 Then
                con.Open()
                Q = "Insert into dbo.Monthly_Statement (Month, Opening_Amount, Closing_Amount) values ( CONVERT(DATE, CONVERT(varchar(10), 2018" & Month.SelectedItem.Value & "01)) ," & Opening_amount & " , " & Closing_amount & ")"
                Dim cmd As New SqlCommand(Q, con)
                cmd.ExecuteNonQuery()
                con.Close()
            Else
                Response.Write("Month Already Closed")
            End If
            Opening_amount = Closing_amount
            Label1.Visible = True
            Label2.Visible = True
            Label4.Visible = True
            Label5.Visible = True
        Else
            Response.Write("FIRST CLOSE PREVIOUS MONTH")
            Label1.Visible = False
            Label2.Visible = False
            Label4.Visible = False
            Label5.Visible = False
        End If

        'Q = "SELECT SUM(Amount) FROM statement WHERE datepart(month,date)=" & Month.SelectedItem.Value & "-1 AND Type = 'Debit'"
        'da = New SqlDataAdapter(Q, con)
        'ds = New DataSet
        'da.Fill(ds)
        'If Not IsDBNull(ds.Tables(0).Rows(0).Item(0)) Then
        '    XDebited = ds.Tables(0).Rows(0).Item(0)
        'Else
        '    XDebited = 0
        'End If

        '###################################

        'Opening_amount = XCredited - XDebited

    End Sub

    'Private Sub Closing_Load(sender As Object, e As EventArgs) Handles Me.Load
    '    If Session("loggedin") <> 1 Then
    '        Response.Redirect("login.aspx")
    '    End If
    'End Sub
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim constr = "Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\WebSite8\WebSite8\App_Data\Database.mdf;Integrated Security=True"
        Dim con As New SqlConnection(constr)
        Dim Q = "SELECT* FROM Monthly_Statement"
        Dim da As New SqlDataAdapter(Q, con)
        Dim ds As New DataSet
        da.Fill(ds)
        GridView1.DataSource = ds
        GridView1.DataBind()
        Label3.Text = "Closed Months"

        Label1.Visible = False
        Label2.Visible = False
        Label4.Visible = False
        Label5.Visible = False

        'Cash Credit

        Q = "SELECT SUM(Amount) FROM statement WHERE Mode = 'Cash' AND Type = 'Credit' "
        da = New SqlDataAdapter(Q, con)
        ds = New DataSet
        da.Fill(ds)
        Dim CCredit As Integer = 0
        If Not IsDBNull(ds.Tables(0).Rows(0).Item(0)) Then
            CCredit = ds.Tables(0).Rows(0).Item(0)
        End If
        'Cash Debit
        Q = "SELECT SUM(Amount) FROM statement WHERE Mode = 'Cash' AND Type = 'Debit' "
        da = New SqlDataAdapter(Q, con)
        ds = New DataSet
        da.Fill(ds)
        Dim CDebit As Integer = 0
        If Not IsDBNull(ds.Tables(0).Rows(0).Item(0)) Then
            CDebit = ds.Tables(0).Rows(0).Item(0)
        End If

        'Bank Credit

        Q = "SELECT SUM(Amount) FROM statement WHERE Mode = 'Bank' AND Type = 'Credit' "
        da = New SqlDataAdapter(Q, con)
        ds = New DataSet
        da.Fill(ds)
        Dim BCredit As Integer = 0
        If Not IsDBNull(ds.Tables(0).Rows(0).Item(0)) Then
            BCredit = ds.Tables(0).Rows(0).Item(0)
        End If

        'Bank Debit

        Q = "SELECT SUM(Amount) FROM statement WHERE Mode = 'Bank' AND Type = 'Debit' "
        da = New SqlDataAdapter(Q, con)
        ds = New DataSet
        da.Fill(ds)
        Dim BDebit As Integer = 0
        If Not IsDBNull(ds.Tables(0).Rows(0).Item(0)) Then
            BDebit = ds.Tables(0).Rows(0).Item(0)
        End If



    End Sub
    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        Dim constr = "Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\WebSite8\WebSite8\App_Data\Database.mdf;Integrated Security=True"
        Dim con As New SqlConnection(constr)
        con.Open()
        Dim Q = "Delete From Monthly_Statement"
        Dim cmd As New SqlCommand(Q, con)
        cmd.ExecuteNonQuery()
        con.Close()
        Response.Write("DATA ENTRIES DELETED")
    End Sub
    Protected Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim cur_month As String = "2018-" & Month.SelectedItem.Value & "-01"
        Response.Redirect("FM_Statement.aspx?mth=" & cur_month)

    End Sub

    Private Sub Closing_Load(sender As Object, e As EventArgs) Handles Me.Load
        '********************     CHECKING SESSION     ********************
        If Not (Session("loggedin") = 1 Or Session("loggedin") = 2) Then
            Response.Redirect("login.aspx")
        End If
        '******************************************************************
    End Sub
End Class
