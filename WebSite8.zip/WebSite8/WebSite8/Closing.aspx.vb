﻿Imports System.Data.SqlClient
Imports System.Data
Partial Class Closing
    Inherits System.Web.UI.Page


    Protected Sub CloseMonth_Click(sender As Object, e As EventArgs) Handles CloseMonth.Click
        Dim constr = "Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\WebSite8\WebSite8\WebSite8\App_Data\Database.mdf;Integrated Security=True"
        Dim con As New SqlConnection(constr)
        'con.Open()

        Dim Q = "SELECT Amount, Type FROM statement WHERE datepart(month,date)=" & Month.SelectedItem.Value & " "
        Dim da As New SqlDataAdapter(Q, con)
        Dim ds As New DataSet
        da.Fill(ds)
        GridView1.DataSource = ds
        GridView1.DataBind()
        Label3.Text = "Monthly Statement"
        Dim Credited As Integer
        Dim Debited As Integer
        Q = "SELECT SUM(Amount) FROM statement WHERE datepart(month,date)=" & Month.SelectedItem.Value & " AND Type = 'Credit'"
        da = New SqlDataAdapter(Q, con)
        ds = New DataSet
        da.Fill(ds)
        If Not IsDBNull(ds.Tables(0).Rows(0).Item(0)) Then
            Credited = ds.Tables(0).Rows(0).Item(0)
        Else
            Credited = 0

        End If

        Q = "SELECT SUM(Amount) FROM statement WHERE datepart(month,date)=" & Month.SelectedItem.Value & " AND Type = 'Debit'"
        da = New SqlDataAdapter(Q, con)
        ds = New DataSet
        da.Fill(ds)
        If Not IsDBNull(ds.Tables(0).Rows(0).Item(0)) Then
            Debited = ds.Tables(0).Rows(0).Item(0)
        Else
            Debited = 0
        End If

        '###########################################
        Dim Opening_amount As Integer = 0
        Dim XCredited As Integer
        Dim XDebited As Integer

        Q = "SELECT SUM(Amount) FROM statement WHERE datepart(month,date)=" & Month.SelectedItem.Value & "-1 AND Type = 'Credit'"
        da = New SqlDataAdapter(Q, con)
        ds = New DataSet
        da.Fill(ds)
        If Not IsDBNull(ds.Tables(0).Rows(0).Item(0)) Then
            XCredited = ds.Tables(0).Rows(0).Item(0)
        Else
            XCredited = 0

        End If

        Q = "SELECT SUM(Amount) FROM statement WHERE datepart(month,date)=" & Month.SelectedItem.Value & "-1 AND Type = 'Debit'"
        da = New SqlDataAdapter(Q, con)
        ds = New DataSet
        da.Fill(ds)
        If Not IsDBNull(ds.Tables(0).Rows(0).Item(0)) Then
            XDebited = ds.Tables(0).Rows(0).Item(0)
        Else
            XDebited = 0
        End If

        '###################################

        Opening_amount = XCredited - XDebited
        Dim Closing_amount As Integer = Opening_amount + Credited - Debited
        Label1.Text = "Closing Balance"
        Label2.Text = Closing_amount
        Label4.Text = "Opening Balance"
        Label5.Text = Opening_amount


        Dim cur_month As String = "2018-" & Month.SelectedItem.Value & "-01"
        Response.Write(cur_month)



        Q = "Select Month From Monthly_Statement WHERE Month = '" & cur_month & "'"
        da = New SqlDataAdapter(Q, con)
        ds = New DataSet
        da.Fill(ds)
        If ds.Tables(0).Rows.Count = 0 Then
            con.Open()
            Q = "Insert into dbo.Monthly_Statement (Month, Opening_Amount, Closing_Amount) values ( CONVERT(DATE, CONVERT(varchar(10), 2018" & Month.SelectedItem.Value & "01)) ," & Opening_amount & " , " & Closing_amount & ")"
            Dim cmd As New SqlCommand(Q, con)
            cmd.ExecuteNonQuery()
            con.Close()
        End If
        Opening_amount = Closing_amount
    End Sub

    Private Sub Closing_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Session("loggedin") <> 1 Then
            Response.Redirect("login.aspx")
        End If
    End Sub
End Class
