﻿Imports System.Data.SqlClient
Imports System.Data

Partial Class login
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim uid As String = TextBox1.Text
        Dim pass As String = TextBox2.Text
        'Dim constr = "Driver={SQL Server};Server=MIS-1;Database=demo;uid=demo;pwd=demo123"
        Dim constr = "Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\WebSite8\WebSite8\App_Data\Database.mdf;Integrated Security=True"
        Dim con As New SqlConnection(constr)
        con.Open()
        Dim Q = "SELECT * FROM demologin WHERE user_id = '" & uid & "'  AND pasword = '" & pass & "' "
        Dim da As New SqlDataAdapter(Q, con)
        Dim ds As New DataSet
        da.Fill(ds)
        If ds.Tables(0).Rows.Count <> 0 Then
            Session("loggedin") = 1
            Response.Redirect("statement.aspx")
        Else
            Label3.Text = "WRONG ID OR PASSWORD"
            Response.Write("TRY AGAIN")
        End If
    End Sub

End Class
