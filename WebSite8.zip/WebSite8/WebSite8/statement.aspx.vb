﻿Imports System.Data.SqlClient
Imports System.Data

Partial Class statement
    Inherits System.Web.UI.Page
    Dim Click As Integer = 0
    Private Sub statement_Load(sender As Object, e As EventArgs) Handles Me.Load

        'If IsPostBack = True Then
        '    Response.Write("LOADED")
        'End If
        If Session("loggedin") <> 1 Then
            Response.Redirect("login.aspx")
        End If
        CurDate.Text = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")
        Dim d As DateTime = "2001-01-01"
        If Calendar1.SelectedDate = d Then
            CurDate.Text = Calendar1.SelectedDate
        End If

        Response.Write(Calendar1.SelectedDate)
    End Sub
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Calendar1.Visible = False


        Dim Cur_Month As Date = CurDate.Text

        Dim CurMonth As Integer = Cur_Month.Month


        Dim constr = "Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\WebSite8\WebSite8\App_Data\Database.mdf;Integrated Security=True"
        Dim con As New SqlConnection(constr)
        con.Open()
        Dim Q = "SELECT Month FROM Monthly_Statement WHERE datepart(month,Month) = " & CurMonth
        Dim da As New SqlDataAdapter(Q, con)
        Dim ds As New DataSet
        da.Fill(ds)
        If (ds.Tables(0).Rows.Count() = 0) Then
            Q = "insert into statement ( Date, Mode, Type, Amount, Description ) Values ('" & CurDate.Text & "','" & Mode.SelectedItem.Text & "','" & Type.SelectedItem.Text & "','" & Amount.Text & "' , '" & Description.Text & "')"
            Dim cmd As New SqlCommand(Q, con)
            cmd.ExecuteNonQuery()
            Response.Write("Enter More Records")
        Else
            Response.Write("MONTH ALREADY CLOSED")

        End If

    End Sub



    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Calendar1.Visible = False
        Dim constr = "Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\WebSite8\WebSite8\App_Data\Database.mdf;Integrated Security=True"
        Dim con As New SqlConnection(constr)
        con.Open()
        Dim Q = "SELECT * FROM statement"
        Dim da As New SqlDataAdapter(Q, con)
        Dim ds As New DataSet

        da.Fill(ds)
        GridView1.DataSource = ds
        GridView1.DataBind()
    End Sub
    Protected Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Response.Redirect("Closing.aspx")
    End Sub
    Protected Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim constr = "Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\WebSite8\WebSite8\App_Data\Database.mdf;Integrated Security=True"
        Dim con As New SqlConnection(constr)
        con.Open()
        Dim Q = "Delete From statement"
        Dim cmd As New SqlCommand(Q, con)
        cmd.ExecuteNonQuery()
        con.Close()
        Response.Write("DATA ENTRIES DELETED")
    End Sub
    Protected Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click

        If Click = 0 Then
            Calendar1.Visible = True
            Click = 1
        Else
            Click = 0
            Calendar1.Visible = False
        End If
    End Sub


End Class
