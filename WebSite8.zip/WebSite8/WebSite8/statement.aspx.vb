﻿Imports System.Data.SqlClient
Imports System.Data
Partial Class statement
    Inherits System.Web.UI.Page

    Private Sub statement_Load(sender As Object, e As EventArgs) Handles Me.Load
        'If IsPostBack = True Then
        '    Response.Write("LOADED")
        'End If
        If Session("loggedin") <> 1 Then
            Response.Redirect("login.aspx")
        End If
        CurDate.Text = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")

    End Sub
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim constr = "Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\WebSite8\WebSite8\WebSite8\App_Data\Database.mdf;Integrated Security=True"
        Dim con As New SqlConnection(constr)
        con.Open()
        Dim Q = "insert into statement ( Date, Mode, Type, Amount, Description ) Values ('" & CurDate.Text & "','" & Mode.SelectedItem.Text & "','" & Type.SelectedItem.Text & "','" & Amount.Text & "' , '" & Description.Text & "')"
        Dim cmd As New SqlCommand(Q, con)
        cmd.ExecuteNonQuery()
        Response.Write("Enter More Records")

    End Sub



    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim constr = "Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\WebSite8\WebSite8\WebSite8\App_Data\Database.mdf;Integrated Security=True"
        Dim con As New SqlConnection(constr)
        con.Open()
        Dim Q = "SELECT * FROM statement"
        Dim da As New SqlDataAdapter(Q, con)
        Dim ds As New DataSet

        da.Fill(ds)
        GridView1.DataSource = ds
        GridView1.DataBind()
    End Sub
    Protected Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Response.Redirect("Closing.aspx")
    End Sub
End Class
